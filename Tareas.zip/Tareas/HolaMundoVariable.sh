#!/bin/bash

#se define una variable
hola="Soy la variable uwu"

echo -n "este scrip te dice :"
echo ${HOLA}
