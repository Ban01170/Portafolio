#!/bin/bash

#Soy un comentario xd
echo "Hola mundo 7w7"
